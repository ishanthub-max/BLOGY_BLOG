# Blogy — Backend Server

A Node.js + Express backend for the Blogy website with a flat-file database (NeDB).
No MySQL or MongoDB installation required — the database is just files in the `/database` folder.

---

## 📁 Folder Structure

```
blog_backend/           ← This folder (backend)
├── server.js           ← Main entry point
├── db.js               ← Database setup
├── seed.js             ← Populate initial data
├── .env                ← Your config (email, password, secret)
├── package.json
├── database/           ← Auto-created. Stores all .db files
│   ├── posts.db
│   ├── comments.db
│   ├── messages.db
│   ├── subscribers.db
│   ├── users.db
│   └── categories.db
├── middleware/
│   └── auth.js         ← JWT authentication
├── routes/
│   ├── auth.js         ← Login / Register
│   ├── posts.js        ← Blog post CRUD
│   ├── comments.js     ← Comment system
│   ├── contact.js      ← Contact form
│   ├── newsletter.js   ← Newsletter subscribe/unsubscribe
│   └── categories.js   ← Blog categories
└── js/
    └── api.js          ← Copy this to: blog_website/js/api.js

blog_website/           ← Your existing HTML website
├── index.html
├── blog.html
├── contact.html
└── ...
```

---

## 🚀 Setup (Step by Step)

### Step 1 — Install Node.js
Download from https://nodejs.org (choose LTS version)

### Step 2 — Install dependencies
Open a terminal inside the `blog_backend` folder and run:
```bash
npm install
```

### Step 3 — Configure your .env file
Open `.env` and update:
```
EMAIL_USER=your_gmail@gmail.com
EMAIL_PASS=your_gmail_app_password    ← Get from Google Account > App Passwords
ADMIN_PASSWORD=YourSecurePassword123
JWT_SECRET=some_long_random_string_here
```

> **Gmail App Password:** Go to myaccount.google.com → Security → 2-Step Verification → App passwords

### Step 4 — Seed the database (first time only)
```bash
node seed.js
```
This creates the admin account and sample blog posts.

### Step 5 — Start the server
```bash
node server.js
```
Open your browser at: **http://localhost:3000**

---

## 🔌 Connect Frontend to Backend

### 1. Copy the API helper file
Copy `js/api.js` → `blog_website/js/api.js`

### 2. Add the script tag to your HTML pages
Add this line before `</body>` in each HTML file:
```html
<script src="js/api.js"></script>
```

### 3. Update your contact form in contact.html
Change the form to use the backend instead of Formspree:
```html
<form id="contactForm">
  <!-- your existing fields, no action needed -->
</form>
```

### 4. Update comment form in single.html
```html
<form id="commentForm" data-post-id="POST_ID_HERE" class="p-5 bg-light">
  <div class="form-group">
    <label>Name *</label>
    <input type="text" name="name" class="form-control" required>
  </div>
  <div class="form-group">
    <label>Email *</label>
    <input type="email" name="email" class="form-control" required>
  </div>
  <div class="form-group">
    <label>Website</label>
    <input type="url" name="website" class="form-control">
  </div>
  <div class="form-group">
    <label>Message</label>
    <textarea name="message" class="form-control" rows="10" required></textarea>
  </div>
  <div class="form-group">
    <input type="submit" value="Post Comment" class="btn btn-primary">
  </div>
  <div id="commentMsg" style="display:none;"></div>
</form>
```

---

## 📡 API Endpoints

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | /api/auth/login | ❌ | Admin login |
| POST | /api/auth/register | ❌ | Create admin account |
| GET | /api/posts | ❌ | Get all posts |
| GET | /api/posts/:slug | ❌ | Get single post |
| POST | /api/posts | ✅ | Create post |
| PUT | /api/posts/:id | ✅ | Update post |
| DELETE | /api/posts/:id | ✅ | Delete post |
| POST | /api/comments | ❌ | Submit comment |
| GET | /api/comments | ✅ | View all comments |
| PATCH | /api/comments/:id/approve | ✅ | Approve comment |
| DELETE | /api/comments/:id | ✅ | Delete comment |
| POST | /api/contact | ❌ | Submit contact form |
| GET | /api/contact | ✅ | View all messages |
| POST | /api/newsletter/subscribe | ❌ | Subscribe |
| POST | /api/newsletter/unsubscribe | ❌ | Unsubscribe |
| GET | /api/newsletter/subscribers | ✅ | View subscribers |
| GET | /api/categories | ❌ | List categories |
| POST | /api/categories | ✅ | Create category |

✅ = Requires `Authorization: Bearer <token>` header

---

## 🔐 Admin Login Example
```javascript
const res = await fetch('http://localhost:3000/api/auth/login', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ email: 'ayantanwar123@gmail.com', password: 'Admin@1234' })
});
const { token } = await res.json();
// Save this token and use it in future requests as:
// Authorization: Bearer <token>
```
