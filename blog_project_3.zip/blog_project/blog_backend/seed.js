// seed.js — Populates the database with initial admin user + sample data
// Run once: node seed.js

require('dotenv').config();
const bcrypt = require('bcryptjs');
const db = require('./db');

async function seed() {
  console.log('🌱 Starting database seed...\n');

  // ── 1. Admin User ──────────────────────────────────
  const existingAdmin = await db.users.findOne({ email: process.env.ADMIN_EMAIL });
  if (!existingAdmin) {
    const hashed = await bcrypt.hash(process.env.ADMIN_PASSWORD, 10);
    await db.users.insert({
      name: 'Ayan Tanwar',
      email: process.env.ADMIN_EMAIL,
      password: hashed,
      role: 'admin',
      createdAt: new Date().toISOString(),
    });
    console.log(`✅ Admin created: ${process.env.ADMIN_EMAIL} / ${process.env.ADMIN_PASSWORD}`);
  } else {
    console.log('ℹ️  Admin already exists, skipping.');
  }

  // ── 2. Categories ──────────────────────────────────
  const cats = ['Culture', 'Business', 'Politics', 'Technology', 'Health', 'Sports'];
  for (const name of cats) {
    const slug = name.toLowerCase();
    try {
      await db.categories.insert({
        name,
        slug,
        description: `Articles about ${name}`,
        createdAt: new Date().toISOString(),
      });
      console.log(`✅ Category: ${name}`);
    } catch (e) {
      console.log(`ℹ️  Category "${name}" already exists.`);
    }
  }

  // ── 3. Sample Blog Posts ───────────────────────────
  const samplePosts = [
    {
      title: "Don't Assume Your Cloud Data Is Safe",
      slug: 'dont-assume-your-cloud-data-is-safe',
      excerpt: "Don't assume your user data in the cloud is safe—take control and protect your information before it's too late.",
      content: `<p>In today's world, many of us rely on cloud storage for our personal and professional data. We trust that our sensitive information is safe and secure. However, this assumption can be dangerous.</p>
<p>Cybersecurity threats continue to evolve, and data breaches are becoming more common, leaving many people vulnerable. Despite the various security measures in place, no system is completely invulnerable.</p>
<p>The best way to protect yourself is to stay informed, use strong unique passwords, enable two-factor authentication, and regularly review which apps have access to your cloud storage.</p>`,
      category: 'Technology',
      tags: ['cloud', 'security', 'data', 'privacy'],
      image: 'images/img_1_sq.jpg',
      status: 'published',
      author: process.env.ADMIN_EMAIL,
      views: 142,
    },
    {
      title: 'Younger Generations Are Reshaping Politics',
      slug: 'younger-generations-reshaping-politics',
      excerpt: "Younger generations are reshaping the political landscape. Here's how their votes could decide the future.",
      content: `<p>For the first time in history, Generation Z and Millennials together outnumber Baby Boomers in the electorate. This shift is already being felt in policy priorities.</p>
<p>Young voters are increasingly focused on issues like climate change, student debt, housing affordability, and digital rights — concerns that older generations often deprioritize.</p>
<p>Pollsters and political strategists are scrambling to understand this demographic, and the parties that successfully engage them could dominate elections for decades to come.</p>`,
      category: 'Politics',
      tags: ['youth', 'elections', 'democracy', 'genz'],
      image: 'images/img_2_sq.jpg',
      status: 'published',
      author: process.env.ADMIN_EMAIL,
      views: 98,
    },
    {
      title: 'Fact-Checking in the Age of Disinformation',
      slug: 'fact-checking-age-of-disinformation',
      excerpt: 'How do you know what is real anymore? A guide to spotting fake news and verifying sources online.',
      content: `<p>The spread of disinformation has accelerated dramatically with social media. False stories can circle the globe before the truth has had a chance to put on its shoes.</p>
<p>Professional fact-checkers use a set of core techniques: tracing original sources, reverse image searching photos, and cross-referencing with multiple independent outlets.</p>
<p>But fact-checking alone is not enough. Media literacy education — teaching people how to evaluate information — is increasingly seen as a public health issue.</p>`,
      category: 'Culture',
      tags: ['media', 'disinformation', 'journalism', 'fakenews'],
      image: 'images/img_3_sq.jpg',
      status: 'published',
      author: process.env.ADMIN_EMAIL,
      views: 211,
    },
    {
      title: 'The Rise of Remote Work Culture',
      slug: 'rise-of-remote-work-culture',
      excerpt: 'Remote work has fundamentally changed how businesses operate and how employees think about their careers.',
      content: `<p>The pandemic forced a massive experiment in remote work, and the results surprised everyone — including the skeptics. Productivity, in many sectors, actually went up.</p>
<p>Companies that once insisted on physical presence are now competing for talent against fully distributed teams. The office as we knew it may never fully return.</p>
<p>But remote work is not without challenges: isolation, blurred work-life boundaries, and inequities between knowledge workers and those who must be physically present.</p>`,
      category: 'Business',
      tags: ['remote', 'work', 'culture', 'productivity'],
      image: 'images/img_4_sq.jpg',
      status: 'published',
      author: process.env.ADMIN_EMAIL,
      views: 175,
    },
  ];

  for (const post of samplePosts) {
    try {
      await db.posts.insert({
        ...post,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });
      console.log(`✅ Post: "${post.title}"`);
    } catch (e) {
      console.log(`ℹ️  Post "${post.title}" already exists.`);
    }
  }

  console.log('\n✅ Seed complete! You can now start the server with: node server.js\n');
  process.exit(0);
}

seed().catch((err) => {
  console.error('❌ Seed failed:', err);
  process.exit(1);
});
