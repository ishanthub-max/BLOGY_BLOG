const express = require('express');
const router = express.Router();
const db = require('../db');
const auth = require('../middleware/auth');

function slugify(text) {
  return text.toString().toLowerCase().trim()
    .replace(/\s+/g, '-').replace(/[^\w\-]+/g, '').replace(/\-\-+/g, '-');
}

router.get('/', async (req, res) => {
  try {
    const categories = await db.categories.find({}).sort({ name: 1 });

    const withCounts = await Promise.all(
      categories.map(async (cat) => {
        const count = await db.posts.count({ category: cat.name, status: 'published' });
        return { ...cat, postCount: count };
      })
    );

    res.json({ categories: withCounts });
  } catch (err) {
    res.status(500).json({ error: 'Server error.', details: err.message });
  }
});

router.post('/', auth, async (req, res) => {
  try {
    const { name, description } = req.body;
    if (!name) return res.status(400).json({ error: 'Category name is required.' });

    const slug = slugify(name);
    const category = await db.categories.insert({
      name,
      slug,
      description: description || '',
      createdAt: new Date().toISOString(),
    });

    res.status(201).json({ message: 'Category created.', category });
  } catch (err) {
    if (err.errorType === 'uniqueViolated')
      return res.status(409).json({ error: 'Category already exists.' });
    res.status(500).json({ error: 'Server error.', details: err.message });
  }
});

router.delete('/:id', auth, async (req, res) => {
  try {
    const numRemoved = await db.categories.remove({ _id: req.params.id }, {});
    if (numRemoved === 0) return res.status(404).json({ error: 'Category not found.' });
    res.json({ message: 'Category deleted.' });
  } catch (err) {
    res.status(500).json({ error: 'Server error.', details: err.message });
  }
});

module.exports = router;
