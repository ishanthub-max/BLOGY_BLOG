const express = require('express');
const router = express.Router();
const db = require('../db');
const auth = require('../middleware/auth');

function slugify(text) {
  return text
    .toString()
    .toLowerCase()
    .trim()
    .replace(/\s+/g, '-')
    .replace(/[^\w\-]+/g, '')
    .replace(/\-\-+/g, '-');
}

router.get('/', async (req, res) => {
  try {
    const { category, search, limit = 10, page = 1 } = req.query;

    let query = { status: 'published' };
    if (category) query.category = category;
    if (search) {
      query.$or = [
        { title: new RegExp(search, 'i') },
        { content: new RegExp(search, 'i') },
        { tags: new RegExp(search, 'i') },
      ];
    }

    const skip = (parseInt(page) - 1) * parseInt(limit);
    const posts = await db.posts
      .find(query)
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit));

    const total = await db.posts.count(query);

    res.json({
      posts,
      pagination: {
        total,
        page: parseInt(page),
        limit: parseInt(limit),
        pages: Math.ceil(total / parseInt(limit)),
      },
    });
  } catch (err) {
    res.status(500).json({ error: 'Server error.', details: err.message });
  }
});

router.get('/:slug', async (req, res) => {
  try {
    const post = await db.posts.findOne({ slug: req.params.slug, status: 'published' });
    if (!post) return res.status(404).json({ error: 'Post not found.' });

    await db.posts.update({ _id: post._id }, { $inc: { views: 1 } });

    const comments = await db.comments
      .find({ postId: post._id, approved: true })
      .sort({ createdAt: -1 });

    res.json({ post, comments });
  } catch (err) {
    res.status(500).json({ error: 'Server error.', details: err.message });
  }
});

router.post('/', auth, async (req, res) => {
  try {
    const { title, content, category, tags, image, status = 'published', excerpt } = req.body;

    if (!title || !content)
      return res.status(400).json({ error: 'Title and content are required.' });

    const slug = slugify(title);

    const post = await db.posts.insert({
      title,
      slug,
      content,
      excerpt: excerpt || content.substring(0, 150) + '...',
      category: category || 'General',
      tags: tags || [],
      image: image || '',
      status,
      author: req.user.email,
      views: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });

    res.status(201).json({ message: 'Post created successfully.', post });
  } catch (err) {
    if (err.errorType === 'uniqueViolated')
      return res.status(409).json({ error: 'A post with this title already exists.' });
    res.status(500).json({ error: 'Server error.', details: err.message });
  }
});

router.put('/:id', auth, async (req, res) => {
  try {
    const { title, content, category, tags, image, status, excerpt } = req.body;

    const updateData = { updatedAt: new Date().toISOString() };
    if (title) { updateData.title = title; updateData.slug = slugify(title); }
    if (content) updateData.content = content;
    if (excerpt) updateData.excerpt = excerpt;
    if (category) updateData.category = category;
    if (tags) updateData.tags = tags;
    if (image) updateData.image = image;
    if (status) updateData.status = status;

    const numUpdated = await db.posts.update(
      { _id: req.params.id },
      { $set: updateData }
    );

    if (numUpdated === 0) return res.status(404).json({ error: 'Post not found.' });

    res.json({ message: 'Post updated successfully.' });
  } catch (err) {
    res.status(500).json({ error: 'Server error.', details: err.message });
  }
});

router.delete('/:id', auth, async (req, res) => {
  try {
    const numRemoved = await db.posts.remove({ _id: req.params.id }, {});
    if (numRemoved === 0) return res.status(404).json({ error: 'Post not found.' });

    await db.comments.remove({ postId: req.params.id }, { multi: true });

    res.json({ message: 'Post and its comments deleted successfully.' });
  } catch (err) {
    res.status(500).json({ error: 'Server error.', details: err.message });
  }
});

module.exports = router;
