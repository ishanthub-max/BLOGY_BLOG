const express = require('express');
const router = express.Router();
const db = require('../db');
const auth = require('../middleware/auth');

router.post('/subscribe', async (req, res) => {
  try {
    const { email, name } = req.body;

    if (!email)
      return res.status(400).json({ error: 'Email is required.' });

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email))
      return res.status(400).json({ error: 'Invalid email address.' });

    const existing = await db.subscribers.findOne({ email });
    if (existing) {
      if (existing.active)
        return res.status(409).json({ error: 'This email is already subscribed.' });

      await db.subscribers.update({ email }, { $set: { active: true, resubscribedAt: new Date().toISOString() } });
      return res.json({ message: 'Welcome back! You have been re-subscribed.' });
    }

    await db.subscribers.insert({
      email,
      name: name || '',
      active: true,
      subscribedAt: new Date().toISOString(),
    });

    res.status(201).json({ message: 'Thank you for subscribing to our newsletter!' });
  } catch (err) {
    if (err.errorType === 'uniqueViolated')
      return res.status(409).json({ error: 'This email is already subscribed.' });
    res.status(500).json({ error: 'Server error.', details: err.message });
  }
});

router.post('/unsubscribe', async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) return res.status(400).json({ error: 'Email is required.' });

    const numUpdated = await db.subscribers.update(
      { email },
      { $set: { active: false, unsubscribedAt: new Date().toISOString() } }
    );

    if (numUpdated === 0)
      return res.status(404).json({ error: 'Email not found in subscribers list.' });

    res.json({ message: 'You have been unsubscribed successfully.' });
  } catch (err) {
    res.status(500).json({ error: 'Server error.', details: err.message });
  }
});

router.get('/subscribers', auth, async (req, res) => {
  try {
    const { active } = req.query;
    let query = {};
    if (active !== undefined) query.active = active === 'true';

    const subscribers = await db.subscribers.find(query).sort({ subscribedAt: -1 });
    const total = await db.subscribers.count({ active: true });

    res.json({ subscribers, totalActive: total });
  } catch (err) {
    res.status(500).json({ error: 'Server error.', details: err.message });
  }
});

router.delete('/subscribers/:id', auth, async (req, res) => {
  try {
    const numRemoved = await db.subscribers.remove({ _id: req.params.id }, {});
    if (numRemoved === 0) return res.status(404).json({ error: 'Subscriber not found.' });
    res.json({ message: 'Subscriber removed.' });
  } catch (err) {
    res.status(500).json({ error: 'Server error.', details: err.message });
  }
});

module.exports = router;
