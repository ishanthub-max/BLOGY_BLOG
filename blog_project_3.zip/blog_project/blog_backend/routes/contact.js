const express = require('express');
const router = express.Router();
const nodemailer = require('nodemailer');
const db = require('../db');
const auth = require('../middleware/auth');

function createTransporter() {
  return nodemailer.createTransport({
    host: process.env.EMAIL_HOST,
    port: parseInt(process.env.EMAIL_PORT),
    secure: false,
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASS,
    },
  });
}

router.post('/', async (req, res) => {
  try {
    const { name, email, subject, message } = req.body;

    if (!name || !email || !subject || !message)
      return res.status(400).json({ error: 'All fields are required.' });

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email))
      return res.status(400).json({ error: 'Invalid email address.' });

    const saved = await db.messages.insert({
      name,
      email,
      subject,
      message,
      read: false,
      createdAt: new Date().toISOString(),
    });

    if (process.env.EMAIL_USER && process.env.EMAIL_PASS !== 'your_gmail_app_password_here') {
      try {
        const transporter = createTransporter();
        await transporter.sendMail({
          from: `"Blogy Contact Form" <${process.env.EMAIL_USER}>`,
          to: process.env.EMAIL_TO,
          subject: `[Blogy] New message: ${subject}`,
          html: `
            <h2>New Contact Form Submission</h2>
            <table style="border-collapse:collapse;width:100%">
              <tr><td style="padding:8px;border:1px solid #ddd;font-weight:bold">Name</td><td style="padding:8px;border:1px solid #ddd">${name}</td></tr>
              <tr><td style="padding:8px;border:1px solid #ddd;font-weight:bold">Email</td><td style="padding:8px;border:1px solid #ddd">${email}</td></tr>
              <tr><td style="padding:8px;border:1px solid #ddd;font-weight:bold">Subject</td><td style="padding:8px;border:1px solid #ddd">${subject}</td></tr>
              <tr><td style="padding:8px;border:1px solid #ddd;font-weight:bold">Message</td><td style="padding:8px;border:1px solid #ddd">${message}</td></tr>
              <tr><td style="padding:8px;border:1px solid #ddd;font-weight:bold">Received</td><td style="padding:8px;border:1px solid #ddd">${new Date().toLocaleString()}</td></tr>
            </table>
          `,
        });
      } catch (emailErr) {
        console.warn('Email notification failed:', emailErr.message);
      }
    }

    res.status(201).json({
      message: 'Thank you! Your message has been received. We will get back to you soon.',
      id: saved._id,
    });
  } catch (err) {
    res.status(500).json({ error: 'Server error.', details: err.message });
  }
});

router.get('/', auth, async (req, res) => {
  try {
    const { read } = req.query;
    let query = {};
    if (read !== undefined) query.read = read === 'true';

    const messages = await db.messages.find(query).sort({ createdAt: -1 });
    const unreadCount = await db.messages.count({ read: false });

    res.json({ messages, unreadCount });
  } catch (err) {
    res.status(500).json({ error: 'Server error.', details: err.message });
  }
});

router.patch('/:id/read', auth, async (req, res) => {
  try {
    const numUpdated = await db.messages.update(
      { _id: req.params.id },
      { $set: { read: true } }
    );
    if (numUpdated === 0) return res.status(404).json({ error: 'Message not found.' });
    res.json({ message: 'Marked as read.' });
  } catch (err) {
    res.status(500).json({ error: 'Server error.', details: err.message });
  }
});

router.delete('/:id', auth, async (req, res) => {
  try {
    const numRemoved = await db.messages.remove({ _id: req.params.id }, {});
    if (numRemoved === 0) return res.status(404).json({ error: 'Message not found.' });
    res.json({ message: 'Message deleted.' });
  } catch (err) {
    res.status(500).json({ error: 'Server error.', details: err.message });
  }
});

module.exports = router;
