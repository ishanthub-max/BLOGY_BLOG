const express = require('express');
const router = express.Router();
const db = require('../db');
const auth = require('../middleware/auth');

router.post('/', async (req, res) => {
  try {
    const { postId, name, email, message, website } = req.body;

    if (!postId || !name || !email || !message)
      return res.status(400).json({ error: 'postId, name, email, and message are required.' });

    const post = await db.posts.findOne({ _id: postId, status: 'published' });
    if (!post) return res.status(404).json({ error: 'Post not found.' });

    const comment = await db.comments.insert({
      postId,
      postTitle: post.title,
      name,
      email,
      website: website || '',
      message,
      approved: false,
      createdAt: new Date().toISOString(),
    });

    res.status(201).json({
      message: 'Comment submitted! It will appear after approval.',
      comment,
    });
  } catch (err) {
    res.status(500).json({ error: 'Server error.', details: err.message });
  }
});

router.get('/', auth, async (req, res) => {
  try {
    const { approved, postId } = req.query;

    let query = {};
    if (approved !== undefined) query.approved = approved === 'true';
    if (postId) query.postId = postId;

    const comments = await db.comments.find(query).sort({ createdAt: -1 });
    res.json({ comments });
  } catch (err) {
    res.status(500).json({ error: 'Server error.', details: err.message });
  }
});

router.patch('/:id/approve', auth, async (req, res) => {
  try {
    const numUpdated = await db.comments.update(
      { _id: req.params.id },
      { $set: { approved: true } }
    );
    if (numUpdated === 0) return res.status(404).json({ error: 'Comment not found.' });
    res.json({ message: 'Comment approved.' });
  } catch (err) {
    res.status(500).json({ error: 'Server error.', details: err.message });
  }
});

router.delete('/:id', auth, async (req, res) => {
  try {
    const numRemoved = await db.comments.remove({ _id: req.params.id }, {});
    if (numRemoved === 0) return res.status(404).json({ error: 'Comment not found.' });
    res.json({ message: 'Comment deleted.' });
  } catch (err) {
    res.status(500).json({ error: 'Server error.', details: err.message });
  }
});

module.exports = router;
