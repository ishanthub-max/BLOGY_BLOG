const API = '/api';

(function initContactForm() {
  const form = document.getElementById('contactForm');
  if (!form) return;

  form.addEventListener('submit', async function (e) {
    e.preventDefault();

    const btn = form.querySelector('[type="submit"]');
    const successBox = document.getElementById('formSuccess');
    const errorBox = document.getElementById('formError');

    btn.disabled = true;
    btn.value = 'Sending...';
    if (successBox) successBox.style.display = 'none';
    if (errorBox) errorBox.style.display = 'none';

    const payload = {
      name: form.querySelector('[name="name"]').value.trim(),
      email: form.querySelector('[name="email"]').value.trim(),
      subject: form.querySelector('[name="subject"]').value.trim(),
      message: form.querySelector('[name="message"]').value.trim(),
    };

    try {
      const res = await fetch(`${API}/contact`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await res.json();

      if (res.ok) {
        if (successBox) { successBox.textContent = '\u2713 ' + data.message; successBox.style.display = 'block'; }
        form.reset();
      } else {
        if (errorBox) { errorBox.textContent = '\u2717 ' + (data.error || 'Something went wrong.'); errorBox.style.display = 'block'; }
      }
    } catch (err) {
      if (errorBox) { errorBox.textContent = '\u2717 Could not connect to server. Please try again.'; errorBox.style.display = 'block'; }
    } finally {
      btn.disabled = false;
      btn.value = 'Send Message';
    }
  });
})();

(function initNewsletter() {
  const form = document.getElementById('newsletterForm');
  if (!form) return;

  form.addEventListener('submit', async function (e) {
    e.preventDefault();
    const emailInput = form.querySelector('[name="email"]') || form.querySelector('[type="email"]');
    const msgBox = document.getElementById('newsletterMsg');

    if (!emailInput) return;

    try {
      const res = await fetch(`${API}/newsletter/subscribe`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: emailInput.value.trim() }),
      });
      const data = await res.json();

      if (msgBox) {
        msgBox.textContent = res.ok ? '\u2713 ' + data.message : '\u2717 ' + (data.error || 'Error.');
        msgBox.style.display = 'block';
        msgBox.style.color = res.ok ? 'green' : 'red';
      }

      if (res.ok) form.reset();
    } catch (err) {
      if (msgBox) { msgBox.textContent = '\u2717 Could not connect to server.'; msgBox.style.display = 'block'; }
    }
  });
})();

(function initCommentForm() {
  const form = document.getElementById('commentForm');
  if (!form) return;

  form.addEventListener('submit', async function (e) {
    e.preventDefault();

    const postId = form.dataset.postId;
    const msgBox = document.getElementById('commentMsg');
    const btn = form.querySelector('[type="submit"]');

    btn.disabled = true;
    btn.value = 'Posting...';

    const payload = {
      postId,
      name: form.querySelector('[name="name"]').value.trim(),
      email: form.querySelector('[name="email"]').value.trim(),
      website: form.querySelector('[name="website"]') ? form.querySelector('[name="website"]').value.trim() : '',
      message: form.querySelector('[name="message"]').value.trim(),
    };

    try {
      const res = await fetch(`${API}/comments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await res.json();

      if (msgBox) {
        msgBox.textContent = res.ok ? '\u2713 ' + data.message : '\u2717 ' + (data.error || 'Error.');
        msgBox.style.display = 'block';
        msgBox.className = res.ok ? 'alert alert-success mt-3' : 'alert alert-danger mt-3';
      }

      if (res.ok) form.reset();
    } catch (err) {
      if (msgBox) { msgBox.textContent = '\u2717 Could not connect to server.'; msgBox.style.display = 'block'; }
    } finally {
      btn.disabled = false;
      btn.value = 'Post Comment';
    }
  });
})();

(function initSearch() {
  const params = new URLSearchParams(window.location.search);
  const query = params.get('q');
  if (!query) return;

  const container = document.getElementById('searchResults');
  const countEl = document.getElementById('searchCount');
  const queryEl = document.getElementById('searchQuery');

  if (queryEl) queryEl.textContent = '"' + query + '"';

  if (!container) return;

  fetch(`${API}/posts?search=${encodeURIComponent(query)}&limit=20`)
    .then(r => r.json())
    .then(data => {
      const posts = data.posts || [];
      if (countEl) countEl.textContent = posts.length;

      if (posts.length === 0) {
        container.innerHTML = '<p class="text-muted">No results found for your search.</p>';
        return;
      }

      container.innerHTML = posts.map(post => `
        <div class="blog-entry d-flex blog-entry-search-item mb-4">
          <a href="single.html?slug=${post.slug}" class="img-link me-4">
            <img src="${post.image || 'images/img_1_sq.jpg'}" alt="${post.title}" class="img-fluid" style="width:100px;height:100px;object-fit:cover;">
          </a>
          <div>
            <div class="category text-uppercase">${post.category}</div>
            <h3><a href="single.html?slug=${post.slug}">${post.title}</a></h3>
            <p>${post.excerpt}</p>
          </div>
        </div>
      `).join('');
    })
    .catch(() => {
      if (container) container.innerHTML = '<p class="text-danger">Could not load search results.</p>';
    });
})();

(function loadCategories() {
  const container = document.getElementById('categoriesList');
  if (!container) return;

  fetch(`${API}/categories`)
    .then(r => r.json())
    .then(data => {
      const cats = data.categories || [];
      container.innerHTML = cats.map(c => `
        <li><a href="category.html?cat=${c.slug}">${c.name} <span>(${c.postCount})</span></a></li>
      `).join('');
    })
    .catch(() => {});
})();
