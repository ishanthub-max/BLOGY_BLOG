const path = require('path');
const Datastore = require('nedb-promises');

const DB_DIR = path.join(__dirname, 'database');

const db = {
  posts: Datastore.create({ filename: path.join(DB_DIR, 'posts.db'), autoload: true }),
  comments: Datastore.create({ filename: path.join(DB_DIR, 'comments.db'), autoload: true }),
  messages: Datastore.create({ filename: path.join(DB_DIR, 'messages.db'), autoload: true }),
  subscribers: Datastore.create({ filename: path.join(DB_DIR, 'subscribers.db'), autoload: true }),
  users: Datastore.create({ filename: path.join(DB_DIR, 'users.db'), autoload: true }),
  categories: Datastore.create({ filename: path.join(DB_DIR, 'categories.db'), autoload: true }),
};

db.posts.ensureIndex({ fieldName: 'slug', unique: true });
db.comments.ensureIndex({ fieldName: 'postId' });
db.subscribers.ensureIndex({ fieldName: 'email', unique: true });
db.users.ensureIndex({ fieldName: 'email', unique: true });
db.categories.ensureIndex({ fieldName: 'slug', unique: true });

module.exports = db;
