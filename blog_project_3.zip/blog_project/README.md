# Blogy — Full-Stack Blog Website

## Project Structure

```
blog_project/
├── blog_backend/      ← Node.js/Express API server
│   ├── server.js      ← Entry point (also serves frontend)
│   ├── routes/        ← API routes (contact, posts, auth, etc.)
│   ├── db.js          ← NeDB flat-file database setup
│   ├── middleware/    ← JWT auth middleware
│   ├── .env           ← Environment variables (configure before running)
│   └── package.json
└── blog_website/      ← Static frontend files (served by backend)
    ├── index.html
    ├── contact.html   ← Contact form → /api/contact
    ├── blog.html
    ├── about.html
    ├── css/
    ├── js/
    └── images/
```

## Setup & Run

### 1. Install dependencies
```bash
cd blog_backend
npm install
```

### 2. Configure environment
Edit `blog_backend/.env`:
```
PORT=3000
JWT_SECRET=change_this_to_a_long_random_string

# Email notifications for contact form (optional)
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USER=your_email@gmail.com
EMAIL_PASS=your_gmail_app_password   ← Generate at myaccount.google.com/apppasswords
EMAIL_TO=your_email@gmail.com

# Admin login
ADMIN_EMAIL=admin@example.com
ADMIN_PASSWORD=Admin@1234
```

### 3. Start the server
```bash
cd blog_backend
npm start
```

Visit: **http://localhost:3000**

---

## Contact Form
The contact form (`contact.html`) submits to **`POST /api/contact`**.
- Messages are saved to `blog_backend/database/messages.db`
- Optional: email notifications sent to `EMAIL_TO` if Gmail App Password is configured
- Admin can view messages via `GET /api/contact` (requires JWT token)

## API Endpoints
| Method | Route | Auth |
|--------|-------|------|
| POST | /api/auth/login | — |
| POST | /api/auth/register | — |
| GET | /api/posts | — |
| POST | /api/posts | ✓ |
| POST | /api/contact | — |
| GET | /api/contact | ✓ |
| POST | /api/newsletter/subscribe | — |
| GET | /api/categories | — |
| GET | /api/health | — |
